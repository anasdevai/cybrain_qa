# Chain module initialization
