# Retrieval module initialization
