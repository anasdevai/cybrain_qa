# Ingestion module initialization
