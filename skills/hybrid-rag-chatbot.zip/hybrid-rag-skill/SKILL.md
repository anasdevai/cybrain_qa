---
name: hybrid-rag-chatbot
description: >
  Complete production guide for building a Hybrid RAG (Retrieval-Augmented Generation) chatbot
  using LangChain, Qdrant, and Gemini/OpenAI. Covers the full pipeline: fetching data from
  external APIs, chunking with metadata, embedding with bge-small-en-v1.5, storing in Qdrant
  with HNSW indexing, hybrid retrieval (dense + BM25), score fusion, cross-encoder reranking,
  context assembly, and grounded LLM response with citations.
  
  ALWAYS use this skill when the user asks about: RAG pipelines, hybrid search, Qdrant setup,
  semantic search with reranking, LangChain RAG chains, ingestion pipelines, vector stores,
  BM25 + dense retrieval, cross-encoder reranking, or building a chatbot over custom data.
  Trigger even if the user only mentions parts of the pipeline (e.g. "how do I ingest API
  data into Qdrant" or "set up reranking in LangChain").
---

# Hybrid RAG Chatbot — Production Skill

Full implementation guide. Follow sections in order. Each section has exact code, parameters,
and rationale. Read the reference file for a section only when directed.

---

## 0. Stack & Parameters (memorize these)

| Component | Choice | Key param |
|---|---|---|
| Orchestration | LangChain | `langchain>=0.2`, `langchain-community` |
| Vector store | Qdrant | cosine, HNSW `m=16 ef=100` |
| Embedding | `BAAI/bge-small-en-v1.5` | 384 dims, normalize=True |
| Sparse retrieval | BM25 via `rank_bm25` | Top-50 |
| Dense retrieval | Qdrant dense | Top-50 |
| Reranker | `cross-encoder/ms-marco-MiniLM-L-6-v2` | Input 20 → Output 5-10 |
| LLM | Gemini 2.5 Flash (or GPT-4o-mini) | temp=0.2, max_tokens=1024 |
| Cache | Redis | TTL=3600s |
| Chunk size | 500 tokens | overlap=50 |
| Fusion weights | 0.7 dense + 0.3 BM25 | tunable |
| Max context | ~3000 tokens | preserve chunk IDs |
| Latency target | <3s total | |
| Recall target | ≥90% @ Top-5 | |

**For detailed code of any section → read** `references/implementations.md`

---

## 1. Project Setup

### Install dependencies

```bash
pip install langchain langchain-community langchain-google-genai \
    qdrant-client sentence-transformers rank-bm25 \
    redis fastapi uvicorn httpx python-dotenv \
    langchain-huggingface
```

### `.env` file

```env
QDRANT_URL=http://localhost:6333
QDRANT_API_KEY=your_key          # leave blank for local
GOOGLE_API_KEY=your_gemini_key
REDIS_URL=redis://localhost:6379
API_BASE_URL=https://your-data-api.com
API_KEY=your_data_api_key
COLLECTION_NAME=hybrid_rag_docs
```

### Run Qdrant locally

```bash
docker run -p 6333:6333 -p 6334:6334 \
  -v $(pwd)/qdrant_storage:/qdrant/storage \
  qdrant/qdrant
```

---

## 2. Data Ingestion from API

**Goal**: Fetch documents from an external API, normalize, attach metadata.

### Metadata schema (mandatory on every chunk)

```python
{
    "source_id": str,       # unique doc ID from API
    "category": str,        # content category
    "timestamp": str,       # ISO 8601
    "tags": list[str],      # domain tags
    "chunk_index": int,     # position within parent doc
    "url": str,             # original source URL
}
```

### API fetcher pattern

```python
# ingestion/api_fetcher.py
import httpx, os
from typing import AsyncGenerator
from langchain_core.documents import Document

class APIDataFetcher:
    def __init__(self):
        self.base_url = os.getenv("API_BASE_URL")
        self.headers = {"Authorization": f"Bearer {os.getenv('API_KEY')}"}
        self.page_size = 100

    async def fetch_all(self, category: str = None) -> list[Document]:
        docs = []
        page = 1
        async with httpx.AsyncClient(timeout=30) as client:
            while True:
                params = {"page": page, "limit": self.page_size}
                if category:
                    params["category"] = category
                resp = await client.get(
                    f"{self.base_url}/documents",
                    headers=self.headers,
                    params=params
                )
                resp.raise_for_status()
                data = resp.json()
                items = data.get("results", [])
                if not items:
                    break
                for item in items:
                    docs.append(Document(
                        page_content=item["content"],
                        metadata={
                            "source_id": item["id"],
                            "category": item.get("category", "general"),
                            "timestamp": item.get("updated_at", ""),
                            "tags": item.get("tags", []),
                            "url": item.get("url", ""),
                            "chunk_index": 0,
                        }
                    ))
                if len(items) < self.page_size:
                    break
                page += 1
        return docs
```

→ **Streaming ingestion**: see `references/implementations.md § Streaming Ingestion`

---

## 3. Chunking

**Always use `RecursiveCharacterTextSplitter` with token counting.**

```python
# ingestion/chunker.py
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
import copy

def chunk_documents(docs: list[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        length_function=len,               # swap for tiktoken if needed
        separators=["\n\n", "\n", ". ", " ", ""],
        keep_separator=True,
    )
    chunked = []
    for doc in docs:
        splits = splitter.split_documents([doc])
        for i, chunk in enumerate(splits):
            chunk.metadata = copy.deepcopy(doc.metadata)
            chunk.metadata["chunk_index"] = i
            chunk.metadata["chunk_id"] = f"{doc.metadata['source_id']}_chunk_{i}"
        chunked.extend(splits)
    return chunked
```

---

## 4. Embedding + Qdrant Storage

### Embedding model setup

```python
# embeddings/embedder.py
from langchain_huggingface import HuggingFaceEmbeddings

def get_embedder() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(
        model_name="BAAI/bge-small-en-v1.5",
        model_kwargs={"device": "cpu"},           # "cuda" if GPU available
        encode_kwargs={
            "normalize_embeddings": True,         # mandatory for cosine
            "batch_size": 64,
        },
    )
```

### Create Qdrant collection (run once)

```python
# storage/qdrant_setup.py
from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance, VectorParams, HnswConfigDiff,
    PayloadSchemaType
)
import os

def create_collection(client: QdrantClient, name: str):
    client.recreate_collection(
        collection_name=name,
        vectors_config=VectorParams(
            size=384,
            distance=Distance.COSINE,
        ),
        hnsw_config=HnswConfigDiff(
            m=16,                   # connections per node — higher = better recall
            ef_construct=100,       # build-time search width — higher = better index
            full_scan_threshold=10_000,
        ),
        on_disk_payload=True,       # large payloads on disk to save RAM
    )
    # Payload indexes for metadata filtering
    for field, schema in [
        ("category", PayloadSchemaType.KEYWORD),
        ("source_id", PayloadSchemaType.KEYWORD),
        ("timestamp", PayloadSchemaType.DATETIME),
        ("tags",      PayloadSchemaType.KEYWORD),
    ]:
        client.create_payload_index(
            collection_name=name,
            field_name=field,
            field_schema=schema,
        )
    print(f"Collection '{name}' created with payload indexes.")
```

### Ingest chunks into Qdrant via LangChain

```python
# storage/ingest.py
from langchain_qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from embeddings.embedder import get_embedder
import os, asyncio
from ingestion.api_fetcher import APIDataFetcher
from ingestion.chunker import chunk_documents
from storage.qdrant_setup import create_collection

async def run_ingestion(category: str = None):
    client = QdrantClient(
        url=os.getenv("QDRANT_URL"),
        api_key=os.getenv("QDRANT_API_KEY") or None,
    )
    collection = os.getenv("COLLECTION_NAME")
    create_collection(client, collection)           # idempotent recreate

    fetcher = APIDataFetcher()
    raw_docs = await fetcher.fetch_all(category=category)
    print(f"Fetched {len(raw_docs)} docs from API")

    chunks = chunk_documents(raw_docs)
    print(f"Produced {len(chunks)} chunks")

    embedder = get_embedder()
    # Batch upsert — LangChain handles batching internally
    vectorstore = await QdrantVectorStore.afrom_documents(
        documents=chunks,
        embedding=embedder,
        url=os.getenv("QDRANT_URL"),
        api_key=os.getenv("QDRANT_API_KEY") or None,
        collection_name=collection,
        batch_size=64,
    )
    print(f"Ingested {len(chunks)} chunks into Qdrant")
    return vectorstore

if __name__ == "__main__":
    asyncio.run(run_ingestion())
```

---

## 5. Hybrid Retrieval (Dense + BM25)

**Build BM25 index from Qdrant payloads at query time (or cache it).**

```python
# retrieval/hybrid_retriever.py
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue
from rank_bm25 import BM25Okapi
from typing import Optional
import numpy as np, os

class HybridRetriever(BaseRetriever):
    vectorstore: QdrantVectorStore
    client: QdrantClient
    collection_name: str
    dense_top_k: int = 50
    bm25_top_k: int = 50
    dense_weight: float = 0.7
    bm25_weight: float = 0.3
    final_top_k: int = 20          # fed to reranker
    category_filter: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True

    def _build_filter(self) -> Optional[Filter]:
        if not self.category_filter:
            return None
        return Filter(
            must=[
                FieldCondition(
                    key="category",
                    match=MatchValue(value=self.category_filter)
                )
            ]
        )

    def _get_bm25_corpus(self) -> tuple[list[Document], BM25Okapi]:
        """Scroll all payloads to build BM25 corpus. Cache in production."""
        points, _ = self.client.scroll(
            collection_name=self.collection_name,
            limit=100_000,
            with_payload=True,
            with_vectors=False,
        )
        docs, tokenized = [], []
        for p in points:
            text = p.payload.get("page_content", "")
            docs.append(Document(
                page_content=text,
                metadata={**p.payload, "qdrant_id": p.id}
            ))
            tokenized.append(text.lower().split())
        return docs, BM25Okapi(tokenized)

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> list[Document]:
        filt = self._build_filter()

        # --- Dense retrieval ---
        dense_results = self.vectorstore.similarity_search_with_score(
            query=query,
            k=self.dense_top_k,
            filter=filt,
        )

        # --- BM25 retrieval ---
        corpus_docs, bm25 = self._get_bm25_corpus()
        bm25_scores = bm25.get_scores(query.lower().split())
        top_bm25_idx = np.argsort(bm25_scores)[::-1][:self.bm25_top_k]
        bm25_results = [
            (corpus_docs[i], float(bm25_scores[i])) for i in top_bm25_idx
        ]

        # --- Score fusion ---
        def norm(scores):
            s = np.array(scores)
            mn, mx = s.min(), s.max()
            return (s - mn) / (mx - mn + 1e-9)

        combined: dict[str, dict] = {}

        d_scores = norm([s for _, s in dense_results])
        for (doc, _), ns in zip(dense_results, d_scores):
            cid = doc.metadata.get("chunk_id", doc.page_content[:40])
            combined[cid] = {
                "doc": doc,
                "score": self.dense_weight * ns,
            }

        b_scores = norm([s for _, s in bm25_results])
        for (doc, _), ns in zip(bm25_results, b_scores):
            cid = doc.metadata.get("chunk_id", doc.page_content[:40])
            if cid in combined:
                combined[cid]["score"] += self.bm25_weight * ns
            else:
                combined[cid] = {
                    "doc": doc,
                    "score": self.bm25_weight * ns,
                }

        ranked = sorted(combined.values(), key=lambda x: x["score"], reverse=True)
        return [r["doc"] for r in ranked[:self.final_top_k]]
```

---

## 6. Reranking

```python
# retrieval/reranker.py
from sentence_transformers import CrossEncoder
from langchain_core.documents import Document

class CrossEncoderReranker:
    def __init__(self, top_n: int = 8):
        self.model = CrossEncoder(
            "cross-encoder/ms-marco-MiniLM-L-6-v2",
            max_length=512,
        )
        self.top_n = top_n

    def rerank(self, query: str, docs: list[Document]) -> list[Document]:
        if not docs:
            return []
        pairs = [(query, doc.page_content) for doc in docs]
        scores = self.model.predict(pairs)
        ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
        top = ranked[:self.top_n]
        for doc, score in top:
            doc.metadata["rerank_score"] = float(score)
        return [doc for doc, _ in top]
```

---

## 7. Context Builder + Citation System

```python
# retrieval/context_builder.py
from langchain_core.documents import Document

MAX_CONTEXT_CHARS = 12_000  # ≈ 3000 tokens

def build_context(docs: list[Document]) -> tuple[str, list[dict]]:
    """Returns (context_string, citation_map)"""
    context_parts = []
    citations = []
    total = 0

    for i, doc in enumerate(docs):
        snippet = doc.page_content.strip()
        if total + len(snippet) > MAX_CONTEXT_CHARS:
            break
        context_parts.append(f"[{i}] {snippet}")
        citations.append({
            "index": i,
            "source_id": doc.metadata.get("source_id", ""),
            "chunk_id": doc.metadata.get("chunk_id", ""),
            "category": doc.metadata.get("category", ""),
            "url": doc.metadata.get("url", ""),
            "rerank_score": doc.metadata.get("rerank_score", 0.0),
        })
        total += len(snippet)

    return "\n\n".join(context_parts), citations
```

---

## 8. LLM Chain (LangChain + Gemini)

```python
# chain/rag_chain.py
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.reranker import CrossEncoderReranker
from retrieval.context_builder import build_context
import os

SYSTEM_PROMPT = """You are a precise research assistant. Answer ONLY using the provided context.
Every factual claim MUST be followed by a citation [N] matching the context index.
If the context doesn't contain the answer, say "I don't have enough information."
Do NOT hallucinate. Do NOT use prior knowledge outside the context."""

USER_PROMPT = """Context:
{context}

Question: {question}

Answer with inline citations [N]:"""

def get_llm():
    return ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0.2,
        max_output_tokens=1024,
        google_api_key=os.getenv("GOOGLE_API_KEY"),
    )

class HybridRAGChain:
    def __init__(
        self,
        retriever: HybridRetriever,
        reranker: CrossEncoderReranker,
    ):
        self.retriever = retriever
        self.reranker = reranker
        self.llm = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT),
            ("human", USER_PROMPT),
        ])

    def invoke(self, query: str, category_filter: str = None) -> dict:
        # Set filter dynamically
        self.retriever.category_filter = category_filter

        # 1. Hybrid retrieval → 20 candidates
        raw_docs = self.retriever.invoke(query)

        # 2. Rerank → Top 8
        reranked = self.reranker.rerank(query, raw_docs)

        # 3. Build context
        context_str, citations = build_context(reranked)

        # 4. LLM call
        chain = self.prompt | self.llm | StrOutputParser()
        answer = chain.invoke({
            "context": context_str,
            "question": query,
        })

        return {
            "answer": answer,
            "citations": citations,
            "num_docs_retrieved": len(raw_docs),
            "num_docs_used": len(reranked),
        }
```

---

## 9. Redis Caching Layer

```python
# cache/redis_cache.py
import redis, json, hashlib, os
from typing import Optional

class RAGCache:
    def __init__(self, ttl: int = 3600):
        self.r = redis.from_url(os.getenv("REDIS_URL"))
        self.ttl = ttl

    def _key(self, query: str, category: Optional[str]) -> str:
        raw = f"{query}::{category or ''}"
        return "rag:" + hashlib.sha256(raw.encode()).hexdigest()

    def get(self, query: str, category: Optional[str]) -> Optional[dict]:
        val = self.r.get(self._key(query, category))
        return json.loads(val) if val else None

    def set(self, query: str, category: Optional[str], result: dict):
        self.r.setex(
            self._key(query, category),
            self.ttl,
            json.dumps(result),
        )
```

---

## 10. FastAPI Endpoint

```python
# main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
from qdrant_client import QdrantClient
from langchain_qdrant import QdrantVectorStore
from embeddings.embedder import get_embedder
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.reranker import CrossEncoderReranker
from chain.rag_chain import HybridRAGChain
from cache.redis_cache import RAGCache
import os

app = FastAPI(title="Hybrid RAG API")

# Startup: initialize shared resources
@app.on_event("startup")
async def startup():
    app.state.cache = RAGCache()
    client = QdrantClient(url=os.getenv("QDRANT_URL"))
    embedder = get_embedder()
    vectorstore = QdrantVectorStore(
        client=client,
        collection_name=os.getenv("COLLECTION_NAME"),
        embedding=embedder,
    )
    retriever = HybridRetriever(
        vectorstore=vectorstore,
        client=client,
        collection_name=os.getenv("COLLECTION_NAME"),
    )
    reranker = CrossEncoderReranker(top_n=8)
    app.state.rag = HybridRAGChain(retriever, reranker)

class QueryRequest(BaseModel):
    query: str
    category: Optional[str] = None

class QueryResponse(BaseModel):
    answer: str
    citations: list[dict]
    cached: bool = False

@app.post("/query", response_model=QueryResponse)
async def query_endpoint(req: QueryRequest):
    if not req.query.strip():
        raise HTTPException(400, "Empty query")

    # Cache hit
    cached = app.state.cache.get(req.query, req.category)
    if cached:
        return QueryResponse(**cached, cached=True)

    result = app.state.rag.invoke(req.query, req.category)
    app.state.cache.set(req.query, req.category, {
        "answer": result["answer"],
        "citations": result["citations"],
    })
    return QueryResponse(answer=result["answer"], citations=result["citations"])

@app.get("/health")
async def health():
    return {"status": "ok"}
```

Run: `uvicorn main:app --host 0.0.0.0 --port 8000 --reload`

---

## 11. Performance Checklist

| Item | Implementation |
|---|---|
| Async ingestion | `asyncio.gather()` over API pages |
| Batch embedding | `batch_size=64` in HuggingFaceEmbeddings |
| Redis cache | SHA-256 keyed, TTL=3600s |
| HNSW tuning | `m=16, ef_construct=100` at index time; `ef=128` at query time |
| BM25 corpus cache | Pickle corpus on first build, reload on restart |
| Qdrant payload index | Mandatory for category/tag filters at scale |

---

## 12. Common Errors & Fixes

| Error | Fix |
|---|---|
| `CollectionNotFound` | Run `create_collection()` before ingestion |
| Embedding dim mismatch | Confirm `size=384` matches bge-small output |
| BM25 returns empty | Ensure corpus built from `page_content`, not empty strings |
| Reranker OOM | Reduce input to reranker from 20 → 10 |
| Redis connection refused | Check `REDIS_URL` env var and Docker status |
| Gemini quota | Switch to `gemini-1.5-flash` or add retry with backoff |
| Slow BM25 at scale | Pickle BM25 index on first build, reload from disk |

---

## 13. Reference Files

- `references/implementations.md` — Extended code: streaming ingestion, BM25 caching,
  async batch embedding, HNSW ef query tuning, LangChain LCEL chain variant,
  full Docker Compose setup, metrics instrumentation.

Read a section from it only when the user needs that specific feature. Do not read the whole
file unless asked.
